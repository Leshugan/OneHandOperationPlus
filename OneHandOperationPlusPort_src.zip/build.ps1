$ErrorActionPreference='Continue'
$env:JAVA_HOME="D:\Programs\Portable Android Build\jdk"; $root=$PSScriptRoot; cd $root
$j="$env:JAVA_HOME\bin"; $sdk="D:\Programs\Portable Android Build\sdk"; $bt="$sdk\build-tools\36.0.0"
$py="D:\Programs\Portable Local AI\ComfyUI\python_embeded\python.exe"
$aj="$sdk\platforms\android-36\android.jar"
if(!(Test-Path key.jks)){ & "$j\keytool.exe" -genkeypair -keystore key.jks -storepass ohop123 -keypass ohop123 -alias ohop -keyalg RSA -keysize 2048 -validity 36500 -dname "CN=Leshugan" 2>&1 | Out-Null }

# 1. fresh decode + patches
if(Test-Path dec){ Remove-Item dec -Recurse -Force }
& "$j\java.exe" -jar apktool.jar d -f -o dec orig.apk 2>&1 | Out-Null
& $py -I patch.py | Select-String -NotMatch "^NEED" | % { $_.Line }
& $py -I res.py

# 2. compat dex
if(Test-Path cbuild){ Remove-Item cbuild -Recurse -Force }
mkdir cbuild\src,cbuild\cls -Force | Out-Null
$cur=$null; $buf=@()
foreach($l in [IO.File]::ReadAllLines("$root\compat\stubs.txt")){
  if($l -like '//FILE *'){ if($cur){ $p="cbuild\src\$cur"; mkdir (Split-Path $p) -Force | Out-Null; [IO.File]::WriteAllLines("$root\$p",$buf) }; $cur=$l.Substring(7); $buf=@() } else { $buf+=$l } }
if($cur){ $p="cbuild\src\$cur"; mkdir (Split-Path $p) -Force | Out-Null; [IO.File]::WriteAllLines("$root\$p",$buf) }
mkdir cbuild\src\sgpx -Force | Out-Null; copy compat\sgpx\*.java cbuild\src\sgpx\
$libs="libs\api.jar;libs\provider.jar;libs\aidl.jar;libs\shared.jar;libs\hab.jar"
$srcs=(Get-ChildItem cbuild\src -Recurse -Filter *.java).FullName
& "$j\javac.exe" -nowarn --release 11 -encoding UTF-8 -cp "$aj;$libs" -d cbuild\cls $srcs 2>&1 | % { "$_" }
$cls=(Get-ChildItem cbuild\cls -Recurse -Filter *.class).FullName
& "$j\java.exe" -cp "$bt\lib\d8.jar" com.android.tools.r8.D8 --release --min-api 34 --lib $aj --output cbuild $cls libs\api.jar libs\provider.jar libs\aidl.jar libs\shared.jar libs\hab.jar 2>&1 | Select-String -NotMatch "^Warning" | % { "$_" }
if(!(Test-Path cbuild\classes.dex)){ throw "compat dex failed" }

# 3. compat dex -> smali_classes2, build, align, sign
Compress-Archive -Path cbuild\classes.dex -DestinationPath cbuild\c.zip -Force
& "$j\java.exe" -jar apktool.jar d -r -f -o cbuild\cdec cbuild\c.zip 2>&1 | Out-Null
Copy-Item cbuild\cdec\smali dec\smali_classes2 -Recurse -Force
& "$j\java.exe" -jar apktool.jar b dec -o unsigned.apk 2>&1 | Select-String -NotMatch "^I: " | % { $_.Line }
if(!(Test-Path unsigned.apk)){ throw "apktool build failed" }
& "$bt\zipalign.exe" -f -p 4 unsigned.apk aligned.apk
& "$bt\apksigner.bat" sign --ks key.jks --ks-pass pass:ohop123 --key-pass pass:ohop123 --out OneHandOperation.apk aligned.apk
del unsigned.apk,aligned.apk,OneHandOperation.apk.idsig -ErrorAction SilentlyContinue
Move-Item -Force OneHandOperation.apk OneHandOperationPlusPort.apk
Remove-Item dec,cbuild -Recurse -Force -ErrorAction SilentlyContinue
"built"