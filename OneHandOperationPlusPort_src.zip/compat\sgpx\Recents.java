package sgpx;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.util.Log;

/** "Recents" action: opens the user's «Недавние One UI» screen when that app is installed and its
 *  service is enabled; otherwise the caller falls back to the system recents. Checked on every call. */
final class Recents {
    static final String PKG = "leshugan.recents";

    static boolean enabled(Context c) {
        try {
            c.getPackageManager().getPackageInfo(PKG, 0);
        } catch (Throwable t) { return false; }
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        for (String part : s.split(":")) {
            if (part.equalsIgnoreCase(PKG + "/" + PKG + ".NavService") || part.equalsIgnoreCase(PKG + "/.NavService")) return true;
        }
        return false;
    }

    /** @return true when the One UI recents screen was started (the system recents must not run). */
    static boolean open() {
        Acc a = Acc.I;
        Context c = a != null ? a : Boot.ctx;
        if (c == null || !enabled(c)) return false;
        try {
            Intent i = new Intent(PKG + ".SHOW")
                .setClassName(PKG, PKG + ".RecentsActivity")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            String fg = Acc.topPackage;
            if (fg != null && !fg.isEmpty() && !fg.equals(c.getPackageName())) i.putExtra("fg", fg);
            c.startActivity(i);
            return true;
        } catch (Throwable t) {
            Log.w(Sh.T, "One UI recents failed, using system recents", t);
            return false;
        }
    }
}
