package sgpx;

import android.content.pm.PackageManager;
import android.os.IBinder;
import android.util.Log;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.io.InputStream;
import java.lang.reflect.Method;
import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuBinderWrapper;
import rikka.shizuku.SystemServiceHelper;

/** Privileged (shell uid) operations through Shizuku. */
public final class Sh {
    static final String T = "SGPX";

    public static boolean alive() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public static boolean ok() {
        try { return alive() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; } catch (Throwable t) { return false; }
    }

    public static boolean run(String cmd) {
        if (!ok()) return false;
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new String[]{"sh", "-c", cmd}, null, null);
            drain(p.getInputStream()); drain(p.getErrorStream());
            int r = p.waitFor();
            if (r != 0) Log.w(T, "cmd exit " + r + ": " + cmd);
            return r == 0;
        } catch (Throwable t) {
            Log.w(T, "cmd failed: " + cmd, t);
            return false;
        }
    }

    static void drain(InputStream s) {
        new Thread(() -> { try { byte[] b = new byte[4096]; while (s.read(b) > 0) {} } catch (Throwable t) {} }).start();
    }

    public static void async(String cmd) { new Thread(() -> run(cmd)).start(); }

    static Object im; static Method inj;

    /** MotionEvent flags stock Android knows. One UI builds events with private flags
     *  (e.g. 0x20400000); the stock input verifier aborts system_server on unknown bits. */
    static final int MOTION_FLAGS = 0x1 | 0x2 | 0x4 | 0x8 | 0x20 | 0x40 | 0x800 | 0x40000000;
    static final int KEY_FLAGS = 0x0000FFFF;

    static InputEvent sanitize(InputEvent e) {
        if (e instanceof MotionEvent) {
            MotionEvent m = (MotionEvent) e;
            if ((m.getFlags() & ~MOTION_FLAGS) == 0) return m;
            int n = m.getPointerCount();
            MotionEvent.PointerProperties[] pp = new MotionEvent.PointerProperties[n];
            MotionEvent.PointerCoords[] pc = new MotionEvent.PointerCoords[n];
            for (int i = 0; i < n; i++) {
                pp[i] = new MotionEvent.PointerProperties(); m.getPointerProperties(i, pp[i]);
                pc[i] = new MotionEvent.PointerCoords(); m.getPointerCoords(i, pc[i]);
            }
            return MotionEvent.obtain(m.getDownTime(), m.getEventTime(), m.getAction(), n, pp, pc,
                m.getMetaState(), m.getButtonState(), m.getXPrecision(), m.getYPrecision(),
                m.getDeviceId(), m.getEdgeFlags(), m.getSource(), m.getFlags() & MOTION_FLAGS);
        }
        if (e instanceof KeyEvent) {
            KeyEvent k = (KeyEvent) e;
            if ((k.getFlags() & ~KEY_FLAGS) == 0) return k;
            return new KeyEvent(k.getDownTime(), k.getEventTime(), k.getAction(), k.getKeyCode(), k.getRepeatCount(),
                k.getMetaState(), k.getDeviceId(), k.getScanCode(), k.getFlags() & KEY_FLAGS, k.getSource());
        }
        return e;
    }

    public static boolean inject(InputEvent e) {
        if (!ok()) return false;
        e = sanitize(e);
        try {
            if (im == null) {
                IBinder b = new ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"));
                im = Class.forName("android.hardware.input.IInputManager$Stub").getMethod("asInterface", IBinder.class).invoke(null, b);
                inj = im.getClass().getMethod("injectInputEvent", InputEvent.class, int.class);
            }
            Object r = inj.invoke(im, e, 0);
            return !(r instanceof Boolean) || (Boolean) r;
        } catch (Throwable t) {
            Log.w(T, "inject failed", t);
            im = null;
            return false;
        }
    }
}
