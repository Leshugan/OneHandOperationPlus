import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class Chk {
    static ClassLoader cl = ClassLoader.getSystemClassLoader();

    static Class<?> cls(String d) throws Exception {
        switch (d) {
            case "Z": return boolean.class; case "B": return byte.class; case "C": return char.class;
            case "S": return short.class; case "I": return int.class; case "J": return long.class;
            case "F": return float.class; case "D": return double.class; case "V": return void.class;
        }
        if (d.startsWith("[")) return Class.forName(d.replace('/', '.'), false, cl);
        if (d.startsWith("L")) d = d.substring(1, d.length() - 1);
        return Class.forName(d.replace('/', '.'), false, cl);
    }

    static List<String> params(String s) {
        List<String> r = new ArrayList<>(); int i = 0;
        while (i < s.length()) {
            int st = i; while (s.charAt(i) == '[') i++;
            if (s.charAt(i) == 'L') i = s.indexOf(';', i);
            i++; r.add(s.substring(st, i));
        }
        return r;
    }

    static Set<Class<?>> allIf(Class<?> c) {
        Set<Class<?>> s = new HashSet<>(); Deque<Class<?>> q = new ArrayDeque<>(Arrays.asList(c.getInterfaces()));
        while (!q.isEmpty()) { Class<?> i = q.poll(); if (s.add(i)) q.addAll(Arrays.asList(i.getInterfaces())); }
        return s;
    }

    static boolean hasMethod(Class<?> c, String n, Class<?>[] p) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { if (n.equals("<init>")) k.getDeclaredConstructor(p); else k.getDeclaredMethod(n, p); return true; } catch (Throwable e) {}
            if (n.equals("<init>")) return false;
            for (Class<?> i : allIf(k)) { try { i.getDeclaredMethod(n, p); return true; } catch (Throwable e) {} }
        }
        if (c.isInterface()) { try { Object.class.getDeclaredMethod(n, p); return true; } catch (Throwable e) {} }
        return false;
    }

    static boolean hasField(Class<?> c, String n) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try { k.getDeclaredField(n); return true; } catch (Throwable e) {}
            for (Class<?> i : allIf(k)) { try { i.getDeclaredField(n); return true; } catch (Throwable e) {} }
        }
        return false;
    }

    public static void main(String[] a) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(a[0]));
        String l;
        while ((l = br.readLine()) != null) {
            String[] t = l.split(" ");
            try {
                if (t[0].equals("C")) { cls("L" + t[1] + ";"); continue; }
                Class<?> c = cls("L" + t[1] + ";");
                String sig = t[3];
                if (sig.startsWith(":")) { if (!hasField(c, t[2])) System.out.println("F " + t[1] + " " + t[2] + " " + sig); continue; }
                String ps = sig.substring(1, sig.indexOf(')'));
                List<String> pl = params(ps); Class<?>[] pc = new Class<?>[pl.size()];
                for (int i = 0; i < pc.length; i++) pc[i] = cls(pl.get(i));
                if (!hasMethod(c, t[2], pc)) System.out.println("M " + t[1] + " " + t[2] + " " + sig);
            } catch (ClassNotFoundException | NoClassDefFoundError e) {
                System.out.println("X " + l + "  // " + e.getMessage());
            }
        }
    }
}
