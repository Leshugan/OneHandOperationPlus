package sgpx;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/** Accessibility service: system-level overlay layer, global actions and keep-alive anchor. */
public class Acc extends AccessibilityService {
    static volatile Acc I;
    public static volatile String topPackage = "";

    @Override protected void onServiceConnected() {
        I = this;
        W.migrate();
        Boot.onAccConnected(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e != null && e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName() != null) {
            topPackage = e.getPackageName().toString();
        }
    }

    @Override public void onInterrupt() {}

    @Override public boolean onUnbind(Intent i) { I = null; return super.onUnbind(i); }

    @Override public void onDestroy() { I = null; super.onDestroy(); }

    public static WindowManager wm() {
        Acc a = I;
        return a == null ? null : (WindowManager) a.getSystemService(WINDOW_SERVICE);
    }

    public static boolean global(int action) {
        Acc a = I;
        return a != null && a.performGlobalAction(action);
    }
}
