package sgpx;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import org.lsposed.hiddenapibypass.HiddenApiBypass;
import rikka.shizuku.Shizuku;

/** Process start hook: hidden API access, Shizuku permission, one-time privileged grants. */
public final class Boot {
    public static volatile Context ctx;
    static boolean granted, listening;

    public static void init(Context c) {
        ctx = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        try { HiddenApiBypass.addHiddenApiExemptions("L"); } catch (Throwable t) { Log.w(Sh.T, "hiddenapi", t); }
        boolean main = ctx.getPackageName().equals(Application.getProcessName());
        if (!main || listening) return;
        listening = true;
        try {
            Shizuku.addRequestPermissionResultListener((code, res) -> { if (res == 0) grantAll(); });
            Shizuku.addBinderReceivedListenerSticky(Boot::onBinder);
        } catch (Throwable t) { Log.w(Sh.T, "shizuku", t); }
    }

    static void onBinder() {
        try {
            if (Shizuku.isPreV11()) return;
            if (Shizuku.checkSelfPermission() == 0) grantAll();
            else if (!Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(7);
        } catch (Throwable t) { Log.w(Sh.T, "onBinder", t); }
    }

    static synchronized void grantAll() {
        if (granted) return;
        granted = true;
        final String p = ctx.getPackageName();
        final String acc = p + "/sgpx.Acc";
        new Thread(() -> {
            String[] cmds = {
                "pm grant " + p + " android.permission.WRITE_SECURE_SETTINGS",
                "pm grant " + p + " android.permission.POST_NOTIFICATIONS",
                "appops set " + p + " SYSTEM_ALERT_WINDOW allow",
                "appops set " + p + " WRITE_SETTINGS allow",
                "appops set " + p + " GET_USAGE_STATS allow",
                "appops set " + p + " RUN_IN_BACKGROUND allow",
                "appops set " + p + " RUN_ANY_IN_BACKGROUND allow",
                "appops set " + p + " AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore",
                "dumpsys deviceidle whitelist +" + p,
                "am set-standby-bucket " + p + " active",
                "s=$(settings get secure enabled_accessibility_services); case \"$s\" in *" + acc + "*) ;; ''|null) settings put secure enabled_accessibility_services " + acc + " ;; *) settings put secure enabled_accessibility_services \"$s:" + acc + "\" ;; esac; settings put secure accessibility_enabled 1",
            };
            for (String c : cmds) Sh.run(c);
            Log.i(Sh.T, "privileged grants applied");
        }).start();
    }

    static void onAccConnected(Context c) {
        try {
            if (c.getSharedPreferences("sidegesturepad_prefs", 0).getBoolean("sidegesturepad_enabled", false))
                Class.forName("n6.y").getMethod("O1", Context.class).invoke(null, c);
        } catch (Throwable t) { Log.w(Sh.T, "start service", t); }
    }
}
