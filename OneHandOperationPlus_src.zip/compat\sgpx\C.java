package sgpx;

import android.app.*;
import android.appwidget.AppWidgetProviderInfo;
import android.content.*;
import android.content.pm.*;
import android.content.res.Configuration;
import android.graphics.drawable.*;
import android.media.AudioManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.lang.reflect.Method;

/** Replacements for Samsung-only framework members (One UI) on stock Android. */
public final class C {
    static Object call(Object o, Class<?> c, String n, Class<?>[] p, Object... a) throws Throwable {
        Method m = c.getMethod(n, p); m.setAccessible(true); return m.invoke(o, a);
    }

    // ---- helpers used by stub classes
    public static boolean panelExpanded() { return false; }
    public static boolean featureBool(String k) { return false; }
    public static String featureString(String k) {
        if (k != null && k.endsWith("CORNER_ROUND")) {
            try {
                android.content.res.Resources r = android.content.res.Resources.getSystem();
                int id = r.getIdentifier("rounded_corner_radius", "dimen", "android");
                float px = id != 0 ? r.getDimension(id) : 0;
                float dp = px / r.getDisplayMetrics().density;
                return String.valueOf(dp > 0 ? dp : 16f);
            } catch (Throwable t) { return "16"; }
        }
        return "";
    }
    public static boolean hotspot(boolean on) { return Sh.run("cmd wifi " + (on ? "start-softap" : "stop-softap")); }

    // ---- ActivityManager
    public static int ActivityManager_semGetCurrentUser() {
        try { return (Integer) call(null, ActivityManager.class, "getCurrentUser", new Class[0]); } catch (Throwable t) { return 0; }
    }
    public static void ActivityManager_semSetProcessImportant(ActivityManager am, IBinder b, int pid, boolean imp) {}
    public static int ActivityManager_RunningAppProcessInfo_semGetProcessState(ActivityManager.RunningAppProcessInfo i) {
        try { return i.getClass().getField("processState").getInt(i); } catch (Throwable t) { return 2; }
    }
    // ---- AlertDialog
    public static void AlertDialog_semSetBackgroundBlurEnabled(AlertDialog d, boolean e) {}
    // ---- KeyguardManager
    public static boolean KeyguardManager_semIsKeyguardShowingAndNotOccluded(KeyguardManager k) { return k.isKeyguardLocked(); }
    // ---- AppWidgetProviderInfo
    public static ComponentName get_AppWidgetProviderInfo_semConfigure(AppWidgetProviderInfo i) { return null; }
    // ---- Context
    public static ComponentName Context_semStartServiceAsUser(Context c, Intent i, UserHandle u) { return c.startService(i); }
    // ---- Intent
    public static void Intent_semSetLaunchOverTargetTask(Intent i, int task, boolean b) {}
    // ---- PackageManager icons
    public static Drawable PackageManager_semGetActivityIconForIconTray(PackageManager pm, ComponentName c, int mode) {
        try { return pm.getActivityIcon(c); } catch (Throwable t) { return pm.getDefaultActivityIcon(); }
    }
    public static Drawable PackageManager_semGetApplicationIconForIconTray(PackageManager pm, ApplicationInfo ai, int mode) { return pm.getApplicationIcon(ai); }
    public static Drawable PackageManager_semGetApplicationIconForIconTray(PackageManager pm, String pkg, int mode) {
        try { return pm.getApplicationIcon(pkg); } catch (Throwable t) { return pm.getDefaultActivityIcon(); }
    }
    public static Drawable PackageManager_semGetDrawableForIconTray(PackageManager pm, Drawable d, int mode) { return d; }
    // ---- Configuration
    public static int get_Configuration_semDesktopModeEnabled(Configuration c) { return 0; }
    public static int get_Configuration_semDisplayDeviceType(Configuration c) { return 0; }
    // ---- AudioManager (fine volume = 10x steps)
    public static int AudioManager_semGetFineVolume(AudioManager a, int s) { return a.getStreamVolume(s) * 10; }
    public static int AudioManager_semGetRingerModeInternal(AudioManager a) { return a.getRingerMode(); }
    public static void AudioManager_semSetFineVolume(AudioManager a, int s, int v, int flags) {
        try { a.setStreamVolume(s, Math.round(v / 10f), flags); } catch (Throwable t) {}
    }
    // ---- Build.VERSION
    public static int get_Build_VERSION_SEM_PLATFORM_INT() { return 170000; }
    // ---- PowerManager
    public static int PowerManager_semGetMaximumScreenBrightnessSetting(PowerManager p) { return 255; }
    public static int PowerManager_semGetMinimumScreenBrightnessSetting(PowerManager p) { return 1; }
    // ---- UserHandle
    public static UserHandle get_UserHandle_SEM_OWNER() { return android.os.Process.myUserHandle(); }
    public static int UserHandle_semGetCallingUserId() { return Binder.getCallingUid() / 100000; }
    public static int UserHandle_semGetMyUserId() { return android.os.Process.myUid() / 100000; }
    public static UserHandle UserHandle_semOf(int id) {
        try { return (UserHandle) call(null, UserHandle.class, "of", new Class[]{int.class}, id); } catch (Throwable t) { return android.os.Process.myUserHandle(); }
    }
    // ---- Vibration
    public static VibrationEffect VibrationEffect_semCreateWaveform(int idx, int rep, VibrationEffect$SemMagnitudeType t) {
        return VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK);
    }
    public static int Vibrator_semGetSupportedVibrationType(Vibrator v) { return 0; }
    public static int HapticFeedbackConstants_semGetVibrationIndex(int i) { return i; }
    // ---- Settings.System
    public static int Settings_System_semGetIntForUser(ContentResolver cr, String n, int def, int user) {
        return Settings.System.getInt(cr, n, def);
    }
    public static boolean Settings_System_semPutIntForUser(ContentResolver cr, String n, int v, int user) {
        try { return Settings.System.putInt(cr, n, v); } catch (Throwable t) { Sh.async("settings put system " + n + " " + v); return false; }
    }
    // ---- protected settings: direct write, else via Shizuku, never crash
    static boolean put(String table, ContentResolver cr, String n, int v) {
        try {
            switch (table) {
                case "global": return Settings.Global.putInt(cr, n, v);
                case "secure": return Settings.Secure.putInt(cr, n, v);
                default: return Settings.System.putInt(cr, n, v);
            }
        } catch (Throwable t) {
            Sh.async("settings put " + table + " " + n + " " + v);
            return false;
        }
    }
    public static boolean putGlobal(ContentResolver cr, String n, int v) { return put("global", cr, n, v); }
    public static boolean putSecure(ContentResolver cr, String n, int v) { return put("secure", cr, n, v); }
    public static boolean putSystem(ContentResolver cr, String n, int v) { return put("system", cr, n, v); }
    // ---- content resolver: Samsung-only providers are absent on other phones
    public static void crRegister(ContentResolver cr, android.net.Uri u, boolean d, android.database.ContentObserver o) {
        try { cr.registerContentObserver(u, d, o); } catch (Throwable t) { android.util.Log.w(Sh.T, "observer " + u + ": " + t); }
    }
    public static Bundle crCall(ContentResolver cr, android.net.Uri u, String m, String a, Bundle b) {
        try { return cr.call(u, m, a, b); } catch (Throwable t) { return null; }
    }
    public static android.net.Uri crInsert(ContentResolver cr, android.net.Uri u, ContentValues v) {
        try { return cr.insert(u, v); } catch (Throwable t) { return null; }
    }
    public static void crNotify(ContentResolver cr, android.net.Uri u, android.database.ContentObserver o) {
        try { cr.notifyChange(u, o); } catch (Throwable t) {}
    }
    public static android.database.Cursor crQuery(ContentResolver cr, android.net.Uri u, String[] p, Bundle a, CancellationSignal s) {
        try { return cr.query(u, p, a, s); } catch (Throwable t) { return null; }
    }
    public static android.database.Cursor crQuery(ContentResolver cr, android.net.Uri u, String[] p, String sel, String[] args, String order) {
        try { return cr.query(u, p, sel, args, order); } catch (Throwable t) { return null; }
    }
    // ---- KeyEvent
    public static void KeyEvent_semSetDisplayId(KeyEvent e, int id) {
        try { call(e, KeyEvent.class, "setDisplayId", new Class[]{int.class}, id); } catch (Throwable t) {}
    }
    // ---- Blur -> rounded translucent background
    static void blur(View v, SemBlurInfo b) {
        if (b == null || !b.hasColor) return;
        GradientDrawable g = new GradientDrawable();
        g.setColor(b.color);
        g.setCornerRadius(b.corner);
        v.setBackground(g);
    }
    public static void ViewGroup_semSetBlurInfo(ViewGroup v, SemBlurInfo b) { blur(v, b); }
    public static void LinearLayout_semSetBlurInfo(LinearLayout v, SemBlurInfo b) { blur(v, b); }
    public static void RelativeLayout_semSetBlurInfo(RelativeLayout v, SemBlurInfo b) { blur(v, b); }
    // ---- WindowManager.LayoutParams
    public static void set_WindowManager_LayoutParams_coverMode(WindowManager.LayoutParams p, int v) {}
    // ---- InputMethodManager
    public static boolean InputMethodManager_semForceHideSoftInput(InputMethodManager m) { return false; }
    public static boolean InputMethodManager_semIsInputMethodShown(InputMethodManager m) {
        try { return (Boolean) call(m, InputMethodManager.class, "isInputMethodShown", new Class[0]); } catch (Throwable t) { return false; }
    }
    // ---- SeekBar
    public static void SeekBar_semSetMode(SeekBar s, int m) {}
}
