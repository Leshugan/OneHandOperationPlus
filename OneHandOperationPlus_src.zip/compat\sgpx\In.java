package sgpx;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.media.AudioManager;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;

/** Key/touch injection: Shizuku first, accessibility/media APIs as fallback. */
public final class In {
    static long down;
    static boolean longSeen;

    public static void key(int code, int action, int flags, int meta) {
        long now = SystemClock.uptimeMillis();
        if (action == 0 && (flags & 128) == 0) { down = now; longSeen = false; }
        if ((flags & 128) != 0) longSeen = true;
        KeyEvent e = new KeyEvent(down, now, action, code, (flags & 128) != 0 ? 1 : 0, meta, -1, 0, flags | 8, 257);
        if (Sh.inject(e)) return;
        fallback(code, action, e);
    }

    static void fallback(int code, int action, KeyEvent e) {
        Context c = Boot.ctx;
        switch (code) {
            case KeyEvent.KEYCODE_VOLUME_UP: case KeyEvent.KEYCODE_VOLUME_DOWN: case KeyEvent.KEYCODE_VOLUME_MUTE:
                if (action == 0 && c != null) {
                    AudioManager a = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                    int dir = code == KeyEvent.KEYCODE_VOLUME_UP ? AudioManager.ADJUST_RAISE : code == KeyEvent.KEYCODE_VOLUME_DOWN ? AudioManager.ADJUST_LOWER : AudioManager.ADJUST_TOGGLE_MUTE;
                    a.adjustSuggestedStreamVolume(dir, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
                }
                return;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: case KeyEvent.KEYCODE_MEDIA_NEXT: case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            case KeyEvent.KEYCODE_MEDIA_PLAY: case KeyEvent.KEYCODE_MEDIA_PAUSE: case KeyEvent.KEYCODE_MEDIA_STOP: case KeyEvent.KEYCODE_HEADSETHOOK:
                if (c != null) ((AudioManager) c.getSystemService(Context.AUDIO_SERVICE)).dispatchMediaKeyEvent(e);
                return;
        }
        if (action != 1 || longSeen) return;
        int g = -1;
        switch (code) {
            case KeyEvent.KEYCODE_BACK: g = AccessibilityService.GLOBAL_ACTION_BACK; break;
            case KeyEvent.KEYCODE_HOME: g = AccessibilityService.GLOBAL_ACTION_HOME; break;
            case KeyEvent.KEYCODE_APP_SWITCH: g = AccessibilityService.GLOBAL_ACTION_RECENTS; break;
            case KeyEvent.KEYCODE_POWER: g = AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN; break;
            case KeyEvent.KEYCODE_SYSRQ: g = AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            case KeyEvent.KEYCODE_NOTIFICATION: g = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS; break;
        }
        if (g >= 0) Acc.global(g);
    }

    public static void motion(Context c, MotionEvent e) {
        Sh.inject(e);
    }
}
