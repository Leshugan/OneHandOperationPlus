package sgpx;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewManager;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

/** Redirects Samsung system window types to accessibility overlays (or app overlays as fallback). */
public final class W {
    static final int ACC = 2032, APP = 2038;
    static final Map<View, WindowManager> map = new WeakHashMap<>();

    static boolean sys(int t) { return t >= 2000 && t < 3000 && t != APP; }

    /** One UI delivers touches to fully transparent windows; stock Android drops them.
     *  Keep touchable overlays a hair above zero so they still receive input. */
    static void visibleForInput(WindowManager.LayoutParams p) {
        boolean touchable = (p.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0;
        if (touchable && p.alpha < 0.01f) p.alpha = 0.01f;
    }

    static WindowManager pick(WindowManager def, WindowManager.LayoutParams p) {
        if (!sys(p.type)) return def;
        visibleForInput(p);
        WindowManager a = Acc.wm();
        if (a != null) { p.type = ACC; return a; }
        p.type = APP;
        return def;
    }

    public static void addView(ViewManager vm, View v, ViewGroup.LayoutParams lp) {
        if (!(vm instanceof WindowManager) || !(lp instanceof WindowManager.LayoutParams)) { vm.addView(v, lp); return; }
        WindowManager.LayoutParams p = (WindowManager.LayoutParams) lp;
        WindowManager t = pick((WindowManager) vm, p);
        try {
            t.addView(v, p);
            synchronized (map) { map.put(v, t); }
        } catch (RuntimeException e) {
            // "already added" etc. belong to the app's own handling
            if (e instanceof IllegalStateException || p.type != ACC) throw e;
            Log.w(Sh.T, "accessibility overlay refused, using app overlay: " + e);
            p.type = APP;
            vm.addView(v, p);
            synchronized (map) { map.put(v, (WindowManager) vm); }
        }
    }

    public static void updateViewLayout(ViewManager vm, View v, ViewGroup.LayoutParams lp) {
        WindowManager t;
        synchronized (map) { t = map.get(v); }
        if (t == null || !(lp instanceof WindowManager.LayoutParams)) { try { vm.updateViewLayout(v, lp); } catch (Throwable e) { Log.e(Sh.T, "update", e); } return; }
        WindowManager.LayoutParams p = (WindowManager.LayoutParams) lp;
        if (sys(p.type)) p.type = (t == Acc.wm()) ? ACC : APP;
        if (p.type == ACC || p.type == APP) visibleForInput(p);
        try { t.updateViewLayout(v, p); } catch (Throwable e) { Log.e(Sh.T, "update", e); }
    }

    public static void removeView(ViewManager vm, View v) {
        WindowManager t;
        synchronized (map) { t = map.remove(v); }
        try { (t != null ? t : vm).removeView(v); } catch (Throwable e) { Log.e(Sh.T, "remove", e); }
    }

    public static void removeViewImmediate(WindowManager vm, View v) {
        WindowManager t;
        synchronized (map) { t = map.remove(v); }
        try { (t != null ? t : vm).removeViewImmediate(v); } catch (Throwable e) { Log.e(Sh.T, "removeImm", e); }
    }

    /** Moves already shown overlays onto the accessibility window layer once the service connects. */
    static void migrate() {
        WindowManager a = Acc.wm();
        if (a == null) return;
        ArrayList<View> vs;
        synchronized (map) { vs = new ArrayList<>(map.keySet()); }
        for (View v : vs) {
            WindowManager old;
            synchronized (map) { old = map.get(v); }
            if (old == null || old == a || !v.isAttachedToWindow()) continue;
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            if (!(lp instanceof WindowManager.LayoutParams)) continue;
            WindowManager.LayoutParams p = (WindowManager.LayoutParams) lp;
            if (p.type != APP) continue;
            try {
                old.removeViewImmediate(v);
                p.type = ACC;
                a.addView(v, p);
                synchronized (map) { map.put(v, a); }
            } catch (Throwable e) { Log.e(Sh.T, "migrate", e); }
        }
    }
}
