"""App-compatibility patcher: points Samsung-only framework members used by the
decompiled smali at local shim helpers (sgpx.*) so the app runs on stock Android."""
import os, re
R = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(R, 'dec')

def rd(p): return open(os.path.join(D, p), encoding='utf-8').read()
def wr(p, s): open(os.path.join(D, p), 'w', encoding='utf-8', newline='\n').write(s)

def body(path, sig, newbody):
    s = rd(path); i = s.find('.method ' + sig); assert i >= 0, (path, sig)
    j = s.find('.end method', i); h = s.find('\n', i)
    wr(path, s[:h + 1] + newbody + '\n' + s[j:])

def after_locals(path, sig, code):
    s = rd(path); i = s.find('.method ' + sig); assert i >= 0, (path, sig)
    k = s.find('.locals', i); e = s.find('\n', k)
    wr(path, s[:e + 1] + code + '\n' + s[e + 1:])

# ---- 1. hand patches: OS gate, key/touch injection, process-start hook
body('smali/n6/y.smali', 'public static a1(Landroid/content/Context;)Z',
     '    .locals 1\n    const/4 v0, 0x1\n    return v0')
body('smali/n6/y.smali', 'public final p1(IIII)V',
     '    .locals 0\n    invoke-static {p1, p2, p3, p4}, Lsgpx/In;->key(IIII)V\n    return-void')
body('smali/a/a.smali', 'public static x(Landroid/content/Context;Landroid/view/MotionEvent;)V',
     '    .locals 0\n    invoke-static {p0, p1}, Lsgpx/In;->motion(Landroid/content/Context;Landroid/view/MotionEvent;)V\n    return-void')
after_locals('smali/com/samsung/android/sidegesturepad/SGPApplication.smali',
     'public final onCreate()V', '    invoke-static {p0}, Lsgpx/Boot;->init(Landroid/content/Context;)V')

# ---- 2. read list of members absent on the device
missing_cls, meths, flds = set(), set(), set()
raw = open(os.path.join(R, 'missing.txt'), 'rb').read()
txt = raw.decode('utf-16') if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else raw.decode('utf-8', 'replace')
for l in txt.splitlines():
    l = l.split('  //')[0].strip()
    if not l or l[0] not in 'XMF': continue
    t = l.split(' ')
    if t[:2] == ['X', 'C']: missing_cls.add(t[2]); continue
    if t[0] == 'X': t = t[1:]
    if t[3].startswith('('): meths.add((t[1], t[2], t[3]))
    else: flds.add((t[1], t[2], t[3].lstrip(':')))
meths = {m for m in meths if m[0] not in missing_cls}   # missing classes are provided as stubs
flds = {f for f in flds if f[0] not in missing_cls}

def simple(c): return c.split('/')[-1].replace('$', '_')
def mres(t): return 'move-result-object' if t[0] in 'L[' else 'move-result'

need = set()
mtab = {'L%s;->%s%s' % m: m for m in meths}
ftab = {'L%s;->%s:%s' % f: f for f in flds}
WM = {
    'Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V':
        'Lsgpx/W;->addView(Landroid/view/ViewManager;Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V',
    'Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V':
        'Lsgpx/W;->updateViewLayout(Landroid/view/ViewManager;Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V',
    'Landroid/view/ViewManager;->removeView(Landroid/view/View;)V':
        'Lsgpx/W;->removeView(Landroid/view/ViewManager;Landroid/view/View;)V',
    'Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V':
        'Lsgpx/W;->removeViewImmediate(Landroid/view/WindowManager;Landroid/view/View;)V',
}
for _k in ('Global', 'Secure', 'System'):
    WM['Landroid/provider/Settings$%s;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z' % _k] = \
        'Lsgpx/C;->put%s(Landroid/content/ContentResolver;Ljava/lang/String;I)Z' % _k
# content resolver calls that throw when a Samsung-only provider is absent -> safe wrappers
for _sig, _name in [
    ('registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V', 'crRegister'),
    ('call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;', 'crCall'),
    ('insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;', 'crInsert'),
    ('notifyChange(Landroid/net/Uri;Landroid/database/ContentObserver;)V', 'crNotify'),
    ('query(Landroid/net/Uri;[Ljava/lang/String;Landroid/os/Bundle;Landroid/os/CancellationSignal;)Landroid/database/Cursor;', 'crQuery'),
    ('query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;', 'crQuery'),
]:
    WM['Landroid/content/ContentResolver;->' + _sig] = 'Lsgpx/C;->%s(Landroid/content/ContentResolver;%s' % (_name, _sig[_sig.index('(') + 1:])
CALL = re.compile(r'^(\s*)invoke-(\w+)(/range)? \{([^}]*)\}, (\S+)\s*$')
FREAD = re.compile(r'^(\s*)([is]get)(-object|-boolean)? (\w+), (?:(\w+), )?(\S+)\s*$')
FWRITE = re.compile(r'^(\s*)iput(-object|-boolean)? (\w+), (\w+), (\S+)\s*$')

def fix(line):
    m = CALL.match(line)
    if m:
        ind, op, rng, regs, ref = m.groups(); rng = rng or ''
        if ref in WM:
            return '%sinvoke-static%s {%s}, %s' % (ind, rng, regs, WM[ref])
        if ref in mtab:
            c, n, sig = mtab[ref]
            if op != 'static':
                sig = '(L%s;%s' % (c, sig[1:])
            tgt = 'Lsgpx/C;->%s_%s%s' % (simple(c), n, sig); need.add(tgt)
            return '%sinvoke-static%s {%s}, %s' % (ind, rng, regs, tgt)
        return line
    m = FREAD.match(line)
    if m and m.group(6) in ftab:
        ind, kind, _, dst, obj, ref = m.groups(); c, n, t = ftab[ref]
        if kind == 'iget':
            tgt = 'Lsgpx/C;->get_%s_%s(L%s;)%s' % (simple(c), n, c, t); args = obj
        else:
            tgt = 'Lsgpx/C;->get_%s_%s()%s' % (simple(c), n, t); args = ''
        need.add(tgt)
        return '%sinvoke-static {%s}, %s\n%s%s %s' % (ind, args, tgt, ind, mres(t), dst)
    m = FWRITE.match(line)
    if m and m.group(5) in ftab:
        ind, _, src, obj, ref = m.groups(); c, n, t = ftab[ref]
        tgt = 'Lsgpx/C;->set_%s_%s(L%s;%s)V' % (simple(c), n, c, t); need.add(tgt)
        return '%sinvoke-static {%s, %s}, %s' % (ind, obj, src, tgt)
    return line

changed = 0
for root, _, fs in os.walk(os.path.join(D, 'smali')):
    for f in fs:
        if not f.endswith('.smali'): continue
        p = os.path.join(root, f)
        s = open(p, encoding='utf-8').read()
        n = '\n'.join(fix(l) for l in s.split('\n'))
        if n != s:
            open(p, 'w', encoding='utf-8', newline='\n').write(n); changed += 1

print('files changed:', changed)
for t in sorted(need): print('NEED', t)
