import os, re
R = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(R, 'dec')
defined = set()
files = []
for d in os.listdir(D):
    if not d.startswith('smali'): continue
    base = os.path.join(D, d)
    for root, _, fs in os.walk(base):
        for f in fs:
            if f.endswith('.smali'):
                p = os.path.join(root, f)
                files.append(p)
                defined.add(os.path.relpath(p, base)[:-6].replace('\\', '/'))
pat = re.compile(r'L([a-zA-Z0-9_/$\-]+);->([a-zA-Z0-9_$<>\-]+)(\([^)]*\)\S+|:\S+)')
cpat = re.compile(r'L((?:android|com/android|dalvik|com/samsung|com/sec)/[a-zA-Z0-9_/$]+);')
refs = set(); classes = set()
for p in files:
    s = open(p, encoding='utf-8').read()
    for m in pat.finditer(s):
        c = m.group(1)
        if c in defined or c.startswith(('java/', 'javax/', 'kotlin')): continue
        refs.add('%s %s %s' % (c, m.group(2), m.group(3)))
    for m in cpat.finditer(s):
        if m.group(1) not in defined: classes.add(m.group(1))
with open(os.path.join(R, 'refs.txt'), 'w', newline='\n') as o:
    for c in sorted(classes): o.write('C %s\n' % c)
    for r in sorted(refs): o.write('M %s\n' % r)
print(len(classes), len(refs))
