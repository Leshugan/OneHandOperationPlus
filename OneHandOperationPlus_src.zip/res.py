"""Manifest/resource additions: accessibility service, Shizuku provider, extra permissions."""
import os, re
R = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(R, 'dec')
PKG = 'com.samsung.android.sidegesturepad'

def rw(p, f):
    p = os.path.join(D, p); s = open(p, encoding='utf-8').read(); n = f(s)
    open(p, 'w', encoding='utf-8', newline='\n').write(n)

perms = ['moe.shizuku.manager.permission.API_V23', 'android.permission.SYSTEM_ALERT_WINDOW',
         'android.permission.POST_NOTIFICATIONS', 'android.permission.EXPAND_STATUS_BAR']
app_add = '''
        <service android:name="sgpx.Acc" android:exported="true" android:label="@string/app_name"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>
            <meta-data android:name="android.accessibilityservice" android:resource="@xml/sgpx_acc"/>
        </service>
        <provider android:name="rikka.shizuku.ShizukuProvider" android:authorities="%s.shizuku"
            android:enabled="true" android:exported="true" android:multiprocess="false"
            android:permission="android.permission.INTERACT_ACROSS_USERS_FULL"/>
        <meta-data android:name="moe.shizuku.client.V3_SUPPORT" android:value="true"/>
    </application>''' % PKG

def man(s):
    # app windows stay out of Recents: swiping them away there lets the OnePlus cleaner kill the gesture process
    s = re.sub(r'<activity (?![^>]*excludeFromRecents)', '<activity android:excludeFromRecents="true" ', s)
    add = ''.join('    <uses-permission android:name="%s"/>\n' % p for p in perms if p not in s)
    s = s.replace('    <uses-permission ', add + '    <uses-permission ', 1)
    return s.replace('</application>', app_add.lstrip(), 1)

rw('AndroidManifest.xml', man)

open(os.path.join(D, 'res/xml/sgpx_acc.xml'), 'w', encoding='utf-8', newline='\n').write(
'''<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault"
    android:canPerformGestures="true"
    android:notificationTimeout="0"
    android:description="@string/sgpx_acc_desc"/>
''')

DESC = {
    'values': 'Lets edge gestures work on any phone: draws the gesture handles above all apps and performs Back, Home, Recents, notifications, screenshot and lock actions.',
    'values-ru': 'Позволяет жестам с края экрана работать на любом телефоне: показывает зоны жестов поверх всех приложений и выполняет «Назад», «Домой», «Недавние», шторку, скриншот и блокировку.',
}
KEEP = {'values': 'Edge gestures are active', 'values-ru': 'Жесты с края экрана активны'}
for d, t in KEEP.items():
    if os.path.exists(os.path.join(D, 'res', d, 'strings.xml')):
        rw(os.path.join('res', d, 'strings.xml'),
           lambda s, t=t: s if 'sgpx_keep_text' in s else s.replace('</resources>', '    <string name="sgpx_keep_text">%s</string>\n</resources>' % t))
for d, t in DESC.items():
    p = os.path.join(D, 'res', d, 'strings.xml')
    if not os.path.exists(p): continue
    rw(os.path.join('res', d, 'strings.xml'),
       lambda s, t=t: s if 'sgpx_acc_desc' in s else s.replace('</resources>', '    <string name="sgpx_acc_desc">%s</string>\n</resources>' % t.replace("'", "\\'")))
# Themes built on the phone's own DeviceDefault theme get One UI colours there; on other
# phones they inherit the vendor palette (dark/brown text). Pin the One UI accent colours.
import re
def pin_colors(s):
    def fix(m):
        head, name, parent = m.group(0), m.group(1), m.group(2)
        mode = 'light' if '.Light' in parent else 'dark'
        items = {
            'android:colorPrimary': '@color/sesl_primary_color_' + mode,
            'android:colorPrimaryDark': '@color/sesl_primary_dark_color_' + mode,
            'android:colorAccent': '@color/sesl_primary_color_' + mode,
            'android:colorControlActivated': '@color/sesl_primary_color_' + mode,
        }
        return head + ''.join('\n        <item name="%s">%s</item>' % kv for kv in items.items())
    s = re.sub(r'<style name="([^"]+)" parent="(@android:style/Theme\.DeviceDefault[^"]*)" */>',
               lambda m: '<style name="%s" parent="%s">\n    </style>' % (m.group(1), m.group(2)), s)
    return re.sub(r'<style name="([^"]+)" parent="(@android:style/Theme\.DeviceDefault[^"]*)">', fix, s)
rw('res/values/styles.xml', pin_colors)
print('res ok')
